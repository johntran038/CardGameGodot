const CARDS = {
	"1_diamond": [1,2],
	"2_diamond": [5,2],
	"3_diamond": [7,1]
}
